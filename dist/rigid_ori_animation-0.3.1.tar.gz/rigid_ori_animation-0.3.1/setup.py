# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['rigid_ori_animation', 'rigid_ori_animation.lib']

package_data = \
{'': ['*']}

install_requires = \
['matplotlib>=3.6.2,<4.0.0',
 'numpy>=1.23.4,<2.0.0',
 'scipy>=1.9.3,<2.0.0',
 'tqdm>=4.64.1,<5.0.0']

setup_kwargs = {
    'name': 'rigid-ori-animation',
    'version': '0.3.1',
    'description': '',
    'long_description': '# SNU Guest Lecture\n\nSome resources for the guest lecture held on 2022.11.15-17.\n\n## Requirements\n\n- Python 3.10.x\n- ParaView (Can be downloaded from [here](https://www.paraview.org/download/))\n\n## List of packages\n\n- resch_animation: Exports animation of the single-orbit hexagonal-triangular Resch origami\n- sc_animation: Exports single crease folding animation\n\n## Usage\n\n### Single-crease\n\nIn root directory of the project, run\n\n```sh\npython -m sc_animation\n```\n\nFor optional arguments, see\n\n```sh\npython -m sc_animation -h\n```\n\n### Miura-ori animation\n\nIn root directory of the project, run\n\n```sh\npython -m miura_animation\n```\n\nWithout arguments, the code generates single unit Miura-ori animation.\nTo define geometry, use the following options.\n\nList of arguments can also be found by\n\n```sh\npython -m miura_animation -h\n```\n\n### Hexagonal-triangular Resch animation\n\nIn root directory of the project, run\n\n```sh\npython -m resch_animation\n```\n\nWithout arguments, the code generates single unit Miura-ori animation.\nTo define geometry, use the following options.\n\nList of arguments can also be found by\n\n```sh\npython -m resch_animation -h\n```\n',
    'author': 'Author',
    'author_email': 'author@author',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
